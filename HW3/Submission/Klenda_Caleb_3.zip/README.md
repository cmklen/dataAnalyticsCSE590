### HW 3
Submission includes pictures in zip and also in report in case there are any issues.
Texts are included in submission as well. 
Project should be run in order of the parts as they are in the `ipynb` file
